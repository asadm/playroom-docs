var PlayerControl = pc.createScript('playerControl');
PlayerControl.attributes.add('speed', { type: 'number' });
PlayerControl.attributes.add('boxSize', { type: 'vec3' });
PlayerControl.attributes.add('player', { type: 'number' });
PlayerControl.attributes.add('defaultPosition', { type: 'vec3' });

var Movements = {
    'up': 1,
    'down': 2,
    'left': 3,
    'right': 4,
    'none': 5
};

// initialize code called once per entity
PlayerControl.prototype.initialize = function () {

    this.player_movementX = Movements.none;
    this.player_movementY = Movements.none;

    this.app.keyboard.on(pc.EVENT_KEYDOWN, this.onKeyDown, this);
    this.app.keyboard.on(pc.EVENT_KEYUP, this.onKeyUp, this);
    this.factorForce = 1;
    //init vars
    // this.isPlayer;
    // this.playerState
    // this.gamePad;
};
PlayerControl.prototype.startPlayer = function (isPlayer, state, pad) {
    this.isPlayer = isPlayer;
    this.playerState = state;
    this.gamePad = pad;

    var pos = this.playerState.getState("position");
    if (pos == undefined || pos == null) {
        this.entity.setPosition(this.defaultPosition);
    }
    this.entity.enabled = true;
    var scope = this;
    if (isPlayer) {
        this.gamePad.joystick.on("move", (e, data) => {
            if (data.direction != null) {
                //console.log(data);
                scope.factorForce = data.force <= 1 ? data.force : 1;
                if (this.AnalizeAngle(data.angle.degree, "x") == "right") {
                    this.player_movementX = Movements.right;
                    this.setCurrentPosition();
                }
                else if (this.AnalizeAngle(data.angle.degree, "x") == "left") {
                    this.player_movementX = Movements.left;
                    this.setCurrentPosition();
                }
                else {
                    this.player_movementX = Movements.none;
                    this.setCurrentPosition();
                }

                if (this.AnalizeAngle(data.angle.degree, "y") == "up") {
                    this.player_movementY = Movements.up;
                    this.setCurrentPosition();
                }
                else if (this.AnalizeAngle(data.angle.degree, "y") == "down") {
                    this.player_movementY = Movements.down;
                    this.setCurrentPosition();
                }
                else {
                    this.player_movementY = Movements.none;
                    this.setCurrentPosition();
                }
            }
        });
        this.gamePad.joystick.on("end", () => {
            this.player_movementX = Movements.none;
            this.player_movementY = Movements.none;
            this.factorForce = 1;
            this.setCurrentPosition();
        });
    }
    //this.playerState.setState("movementX", this.player_movementX);
    //this.playerState.setState("movementY", this.player_movementX);
};
PlayerControl.prototype.AnalizeAngle = function (angle, axis) {
    var direccion = "none";
    if (axis == "x") {
        if (angle >= 0 && angle <= 30)
            direccion = "right";
        else if (angle > 30 && angle < 60)
            direccion = "right";
        else if (angle >= 60 && angle <= 90)
            direccion = "none";
        else if (angle > 90 && angle <= 120)
            direccion = "none"
        else if (angle > 120 && angle < 150)
            direccion = "left";
        else if (angle >= 150 && angle <= 180)
            direccion = "left";
        else if (angle > 180 && angle < 210)
            direccion = "left";
        else if (angle > 210 && angle < 240)
            direccion = "left";
        else if (angle >= 240 && angle <= 270)
            direccion = "none";
        else if (angle > 270 && angle < 300)
            direccion = "none";
        else if (angle > 300 && angle < 330)
            direccion = "right";
        else if (angle >= 330 && angle <= 360)
            direccion = "right";
    }
    else if (axis == "y") {
        if (angle >= 0 && angle <= 30)
            direccion = "none";
        else if (angle > 30 && angle < 60)
            direccion = "up";
        else if (angle >= 60 && angle <= 90)
            direccion = "up";
        else if (angle > 90 && angle <= 120)
            direccion = "up"
        else if (angle > 120 && angle < 150)
            direccion = "up";
        else if (angle >= 150 && angle <= 180)
            direccion = "none";
        else if (angle > 180 && angle < 210)
            direccion = "none";
        else if (angle > 210 && angle < 240)
            direccion = "down";
        else if (angle >= 240 && angle <= 270)
            direccion = "down";
        else if (angle > 270 && angle < 300)
            direccion = "down";
        else if (angle > 300 && angle < 330)
            direccion = "down";
        else if (angle >= 330 && angle <= 360)
            direccion = "none";
    }
    //console.log("axis " + axis + " " + direccion);
    return (direccion);
};
PlayerControl.prototype.endPlayer = function (isPlayer) {
    this.entity.enabled = false;
    this.playerState.setState("position", null);
    if (isPlayer) {
        this.gamePad.joystick.off("move");
        this.gamePad.joystick.off("end");
    }
};

// update code called every frame
PlayerControl.prototype.update = function (dt) {

    if (!this.entity.enabled || this.playerState == null)
        return;

    //this.player_movementX = this.playerState.getState("movementX");
    //this.player_movementY = this.playerState.getState("movementY");
    if (this.isPlayer) {
        var x = 0;
        var z = 0;
        if (this.player_movementX != Movements.none) {
            switch (this.player_movementX) {
                case Movements.left:
                    x = -this.speed * dt * this.factorForce;
                    break;
                case Movements.right:
                    x = this.speed * dt * this.factorForce;
                    break;
            }
        }
        if (this.player_movementY != Movements.none) {
            switch (this.player_movementY) {

                case Movements.up:
                    z = -this.speed * dt * this.factorForce;
                    break;
                case Movements.down:
                    z = this.speed * dt * this.factorForce;
                    break;
            }
        }
        this.MovePlayer(x, 0, z);
    }
    else {
        var pos = this.playerState.getState("position");
        if (pos != undefined && pos != null) {
            this.entity.setPosition(pos.x, pos.y, pos.z);
        }
    }
};
PlayerControl.prototype.setCurrentPosition = function () {
    var pos = this.entity.getPosition();
    this.playerState.setState("position", {
        x: pos.x.toFixed(3),
        y: pos.y.toFixed(3),
        z: pos.z.toFixed(3)
    });
}

PlayerControl.prototype.onKeyDown = function (event) {
    if (!this.isPlayer)
        return;

    if ((event.key == pc.KEY_LEFT && this.app.keyboard.wasPressed(pc.KEY_LEFT)) || (event.key == pc.KEY_A && this.app.keyboard.wasPressed(pc.KEY_A))) {

        this.player_movementX = Movements.left;
        //this.playerState.setState("movementX", this.player_movementX);
        this.setCurrentPosition();
    }

    if ((event.key == pc.KEY_RIGHT && this.app.keyboard.wasPressed(pc.KEY_RIGHT)) || (event.key == pc.KEY_D && this.app.keyboard.wasPressed(pc.KEY_D))) {

        this.player_movementX = Movements.right;
        //this.playerState.setState("movementX", this.player_movementX);
        this.setCurrentPosition();
    }

    if ((event.key == pc.KEY_UP && this.app.keyboard.wasPressed(pc.KEY_UP)) || (event.key == pc.KEY_W && this.app.keyboard.wasPressed(pc.KEY_W))) {

        this.player_movementY = Movements.up;
        //this.playerState.setState("movementY", this.player_movementY);
        this.setCurrentPosition();
    }

    if ((event.key == pc.KEY_DOWN && this.app.keyboard.wasPressed(pc.KEY_DOWN)) || (event.key == pc.KEY_S && this.app.keyboard.wasPressed(pc.KEY_S))) {

        this.player_movementY = Movements.down;
        //this.playerState.setState("movementY", this.player_movementY);
        this.setCurrentPosition();
    }


};
PlayerControl.prototype.onKeyUp = function (event) {

    if (!this.isPlayer)
        return;

    if (event.key == pc.KEY_LEFT || event.key == pc.KEY_A) {

        if (this.player_movementX == Movements.left) {
            this.player_movementX = Movements.none;
            //this.playerState.setState("movementX", this.player_movementX);
            this.setCurrentPosition();
        }
    }

    if (event.key == pc.KEY_RIGHT || event.key == pc.KEY_D) {

        if (this.player_movementX == Movements.right) {
            this.player_movementX = Movements.none;
            //this.playerState.setState("movementX", this.player_movementX);
            this.setCurrentPosition();
        }

    }

    if (event.key == pc.KEY_UP || event.key == pc.KEY_W) {

        if (this.player_movementY == Movements.up) {
            this.player_movementY = Movements.none;
            //this.playerState.setState("movementY", this.player_movementY);
            this.setCurrentPosition();
        }

    }

    if (event.key == pc.KEY_DOWN || event.key == pc.KEY_S) {

        if (this.player_movementY == Movements.down) {
            this.player_movementY = Movements.none;
            //this.playerState.setState("movementY", this.player_movementY);
            this.setCurrentPosition();
        }
    }


};
PlayerControl.prototype.MovePlayer = function (x, y, z) {

    this.entity.translateLocal(x, y, z);

    var pos = this.entity.getLocalPosition();
    if (pos.x < -this.boxSize.x)
        this.entity.setLocalPosition(-this.boxSize.x, pos.y, pos.z);
    else if (pos.x > this.boxSize.x)
        this.entity.setLocalPosition(this.boxSize.x, pos.y, pos.z);

    if (pos.z < -this.boxSize.z)
        this.entity.setLocalPosition(pos.x, pos.y, -this.boxSize.z);
    else if (pos.z > this.boxSize.z)
        this.entity.setLocalPosition(pos.x, pos.y, this.boxSize.z);

    this.setCurrentPosition();
}