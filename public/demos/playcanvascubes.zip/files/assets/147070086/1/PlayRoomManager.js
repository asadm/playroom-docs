const { onPlayerJoin, insertCoin, isHost, myPlayer, getState, setState } = Playroom;
var PlayRoomManager = pc.createScript('playRoomManager');
PlayRoomManager.attributes.add('playersEntity', { type: 'entity', array: true });
// initialize code called once per entity
PlayRoomManager.prototype.initialize = async function () {

    var scope = this;
    this.numPlayers = 0;
    this.numPlayersServer = 0;
    this.playerClass = [null, null, null, null];
    this.listPlayersForJoin = [];
    

    this.playRoom = Playroom;
    this.instance = this;
    this.gamePadHost = null;
    await insertCoin();
    console.log("Game started");
    var nump = this.playRoom.getState("numPlayers");
    if (nump == null || nump == undefined)
        nump = 0;
    this.numPlayersServer = nump;

    onPlayerJoin(playerState => {
        console.log("Player joined", playerState);
        if (playerState.id == playerState.myId) {

            if (this.gamePadHost == null) {
                this.gamePadHost = scope.GamePadConfig(playerState, "dynamic");
            }
        }
        scope.AddPlayer(playerState);
        playerState.onQuit(() => {
            console.log("Player quit")
            scope.RemovePlayer(playerState);
        });
    });
};
PlayRoomManager.prototype.GamePadConfig = function (state, type) {

    if (type == "basic_static") {
        var joystick = new this.playRoom.Joystick(state, {
            type: "dpad",
            /*buttons: [
                { id: "move", label: "move" }
            ]*/
        });
    }
    else if (type == "dynamic") {
        var joystick = nipplejs.create({
            color: 'green'
        }
        );
    }
    else {
        var joystick = null;
    }
    const gp = joystick;
    var pad = new PlayerGamePad(state, gp);
    return (pad);
};
PlayRoomManager.prototype.AddPlayer = function (playerState) {

    var finalStep = false;
    this.numPlayers = this.numPlayers + 1;
    if (this.numPlayers > this.numPlayersServer) {
        this.numPlayersServer = this.numPlayers;
        this.playRoom.setState("numPlayers", this.numPlayersServer);
        finalStep = true;
    }
    this.listPlayersForJoin.push(playerState);

    if (finalStep) {

        for (var i = 0; i < this.listPlayersForJoin.length; i++) {
            var state = this.listPlayersForJoin[i];
            var playerNum = state.getState("playerNum");
            if (playerNum == undefined || playerNum == null)
                state.setState("playerNum", this.numPlayers);
        }

        for (var i = 0; i < this.listPlayersForJoin.length; i++) {

            var playerNum = this.listPlayersForJoin[i].getState("playerNum");
            var state = this.listPlayersForJoin[i];
            var pad = state.id == state.myId ? this.gamePadHost : null;
            this.playerClass[playerNum - 1] = new PlayerClass(state.id, this.playersEntity[playerNum - 1], this.playersEntity[playerNum - 1].script.playerControl, state.id == state.myId ? true : false, playerNum, pad);
            this.playerClass[playerNum - 1].control.startPlayer(this.playerClass[playerNum - 1].host, state, pad);

        }
    }

};
PlayRoomManager.prototype.RemovePlayer = function (playerState) {

    var len = this.playerClass.length;
    for (var i = 0; i < len; i++) {
        if (this.playerClass[i].id == playerState.id) {
            this.playerClass[i].control.endPlayer();
            this.playerClass[i] = null;
            break;
        }
    }
    var len = this.listPlayersForJoin.length;
    for (var i = 0; i < len; i++) {
        if (this.listPlayersForJoin[i].id == playerState.id) {
            this.listPlayersForJoin.splice(i, 1);
            break;
        }
    }
    this.numPlayers = this.numPlayers - 1;
    this.numPlayersServer = this.numPlayersServer - 1;
    this.playRoom.setState("numPlayers", this.numPlayersServer);

};

PlayRoomManager.prototype.update = function (dt) {

};

class PlayerClass {
    constructor(id, entity, control, host, playerNum, pad) {
        this.id = id;
        this.entity = entity;
        this.control = control;
        this.host = host;
        this.playerNum = playerNum;
        this.pad = pad;
    }
}
class PlayerGamePad {
    constructor(state, joystick) {
        this.state = state;
        this.joystick = joystick;
    }
}

